const { app, BrowserWindow, ipcMain } = require("electron");
const path = require("path");
const db = require("./db");

function createWindow() {
  const win = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
    },
  });

  if (process.env.NODE_ENV === "development") {
    win.loadURL("http://localhost:3000");
  } else {
    win.loadFile(path.join(__dirname, "build", "index.html"));
  }
}

app.whenReady().then(() => {
  createWindow();
});

// IPC handlers (students, subjects, categories, assignments, grades)
ipcMain.handle("get-students", () => db.getStudents());
ipcMain.handle("add-student", (event, name) => db.addStudent(name));
ipcMain.handle("get-subjects", () => db.getSubjects());
ipcMain.handle("add-subject", (event, name) => db.addSubject(name));
ipcMain.handle("get-categories", (event, subjectId) => db.getCategories(subjectId));
ipcMain.handle("add-category", (event, subjectId, name) => db.addCategory(subjectId, name));
ipcMain.handle("get-assignments", (event, categoryId) => db.getAssignments(categoryId));
ipcMain.handle("add-assignment", (event, categoryId, title, maxScore) => db.addAssignment(categoryId, title, maxScore));
ipcMain.handle("get-grades", (event, assignmentId) => db.getGrades(assignmentId));
ipcMain.handle("add-grade", (event, assignmentId, studentId, score) => db.addGrade(assignmentId, studentId, score));