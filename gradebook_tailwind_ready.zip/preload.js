const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("api", {
  getStudents: () => ipcRenderer.invoke("get-students"),
  addStudent: (name) => ipcRenderer.invoke("add-student", name),
  getSubjects: () => ipcRenderer.invoke("get-subjects"),
  addSubject: (name) => ipcRenderer.invoke("add-subject", name),
  getCategories: (subjectId) => ipcRenderer.invoke("get-categories", subjectId),
  addCategory: (subjectId, name) => ipcRenderer.invoke("add-category", subjectId, name),
  getAssignments: (categoryId) => ipcRenderer.invoke("get-assignments", categoryId),
  addAssignment: (categoryId, title, maxScore) => ipcRenderer.invoke("add-assignment", categoryId, title, maxScore),
  getGrades: (assignmentId) => ipcRenderer.invoke("get-grades", assignmentId),
  addGrade: (assignmentId, studentId, score) => ipcRenderer.invoke("add-grade", assignmentId, studentId, score),
});