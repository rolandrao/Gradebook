const path = require("path");
const { app } = require("electron");
const Database = require("better-sqlite3");

const dbPath = path.join(app.getPath("userData"), "gradebook.db");
const db = new Database(dbPath);

db.exec(`
  CREATE TABLE IF NOT EXISTS students (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS subjects (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS categories (id INTEGER PRIMARY KEY AUTOINCREMENT, subject_id INTEGER NOT NULL, name TEXT NOT NULL, FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE CASCADE);
  CREATE TABLE IF NOT EXISTS assignments (id INTEGER PRIMARY KEY AUTOINCREMENT, category_id INTEGER NOT NULL, title TEXT NOT NULL, max_score REAL NOT NULL, FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE CASCADE);
  CREATE TABLE IF NOT EXISTS grades (id INTEGER PRIMARY KEY AUTOINCREMENT, assignment_id INTEGER NOT NULL, student_id INTEGER NOT NULL, score REAL, FOREIGN KEY(assignment_id) REFERENCES assignments(id) ON DELETE CASCADE, FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE);
`);

// Export CRUD functions (students, subjects, categories, assignments, grades)
function getStudents() { return db.prepare("SELECT * FROM students").all(); }
function addStudent(name) { const stmt=db.prepare("INSERT INTO students(name) VALUES (?)"); const info=stmt.run(name); return {id:info.lastInsertRowid,name}; }
function getSubjects(){ return db.prepare("SELECT * FROM subjects").all(); }
function addSubject(name){ const stmt=db.prepare("INSERT INTO subjects(name) VALUES (?)"); const info=stmt.run(name); return {id:info.lastInsertRowid,name}; }
function getCategories(subjectId){ return db.prepare("SELECT * FROM categories WHERE subject_id=?").all(subjectId); }
function addCategory(subjectId,name){ const stmt=db.prepare("INSERT INTO categories(subject_id,name) VALUES (?,?)"); const info=stmt.run(subjectId,name); return {id:info.lastInsertRowid,subjectId,name}; }
function getAssignments(categoryId){ return db.prepare("SELECT * FROM assignments WHERE category_id=?").all(categoryId); }
function addAssignment(categoryId,title,maxScore){ const stmt=db.prepare("INSERT INTO assignments(category_id,title,max_score) VALUES (?,?,?)"); const info=stmt.run(categoryId,title,maxScore); return {id:info.lastInsertRowid,categoryId,title,maxScore}; }
function getGrades(assignmentId){ return db.prepare("SELECT * FROM grades WHERE assignment_id=?").all(assignmentId); }
function addGrade(assignmentId,studentId,score){ const stmt=db.prepare("INSERT INTO grades(assignment_id,student_id,score) VALUES (?,?,?)"); const info=stmt.run(assignmentId,studentId,score); return {id:info.lastInsertRowid,assignmentId,studentId,score}; }

module.exports={getStudents,addStudent,getSubjects,addSubject,getCategories,addCategory,getAssignments,addAssignment,getGrades,addGrade};